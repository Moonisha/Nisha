#ifndef LED_H
#define LED_H

#include "Globals.h"

class LED
{
  public:
    void flash(int red, int green, int blue);
    void setColor(bool red, bool green, bool blue);
    
  private:
};
#endif



//gi


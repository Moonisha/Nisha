#include "LED.h"
#include "Arduino.h"

void LED::flash(int red, int green, int blue)
{
  int off = 0;
  if (WIRING_ON == LOW)
  {
    red = abs(red - 255);
    green = abs(green - 255);
    blue = abs(blue - 255);
    off = 255; //crt 01516 TODO: use of off variable?
  }
  
  for (int i = 0; i < BLINK_COUNT; i++) {
    analogWrite(RED_LED, red);
    analogWrite(GREEN_LED, green);
    analogWrite(BLUE_LED, blue);
    SimbleeBLE_ULPDelay(BLINK_DELAY_TIME_MS);
    setColor(false, false, false);
    SimbleeBLE_ULPDelay(BLINK_DELAY_TIME_MS);
  }
}

void LED::setColor(bool red, bool green, bool blue)
{
  if (!WIRING_ON)
  {
    digitalWrite(RED_LED, !red);
    digitalWrite(GREEN_LED, !green);
    digitalWrite(BLUE_LED, !blue);
  }
  else
  {
    digitalWrite(RED_LED, red);
    digitalWrite(GREEN_LED, green);
    digitalWrite(BLUE_LED, blue);
  }
}


//gi

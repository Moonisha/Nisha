#ifndef FSM_PAIR_H
#define FSM_PAIR_H

#include <stdint.h>
#include <Arduino.h>
#include "Globals.h"
#include "Flash.h"
#include "BLEWake.h"
#include "Packet.h"
#include "Button.h"
#include "LED.h"

// Outputs
#define RED_LED_ON 0     // RED
#define GREEN_LED_ON 1   // GREEN
#define BLUE_LED_ON 2    // BLUE
#define MOTOR_ON 3       // MOTOR
#define RADIO_ON 4       // RADIO
#define SET_PAIR 5       // PAIR
#define PAIR_ACK 6       // ACK
 #define FLASH_LEDS 7     // FLASH
#define SLEEP 8          // SLEEP
#define RESET_H_FSM  9   // RESET H_FSM

#define SLEEP_OUTPUT (1 << SLEEP)
#define ADV_OUTPUT (1 << RADIO_ON) | (1 << BLUE_LED_ON)
#define WAIT_OUTPUT (1 << RED_LED_ON) | (1 << RADIO_ON)
#define PAIRED_OUTPUT (1 << SET_PAIR)  | (1 << FLASH_LEDS)
#define PAIR_ACK_OUTPUT (1 << PAIR_ACK) | (1 << RADIO_ON) | (1 << RESET_H_FSM)

class FSM_Pair
{
  public:
    typedef enum {SLEEP_S, ADV_S, WAIT_S, PAIRED_S, PAIR_ACK_S, NumberOfStates} States;
    typedef enum {NONE_I, BTN_UNPAIRED_I, BTN_PAIRED_I, CONNECTED_I, PAIR_COMMAND_I, ADV_TO_I, CONN_TO_I, NumberOfInputs} Inputs;


    typedef struct fsm_item
    {
      int64_t timeOutTime;
      uint16_t output;
      uint16_t nextState[NumberOfInputs];
    } fsm_item_s;

    fsm_item_s fsm[NumberOfStates] = { //BTN_UNPAIRED, BTN_PAIRED, CONNECTED, PAIR_COMMAND, ADV_TO, CONN_TO,
      /* 0 - SLEEP    */ {INFINITE,         SLEEP_OUTPUT,     {SLEEP_S,   ADV_S,    ADV_S, SLEEP_S, SLEEP_S, SLEEP_S, SLEEP_S}},
      /* 1 - ADV      */ {SECONDS(10),      ADV_OUTPUT,       {SLEEP_S,   WAIT_S,   WAIT_S, WAIT_S, SLEEP_S, SLEEP_S, SLEEP_S}},
      /* 2 - WAIT     */ {SECONDS(10),      WAIT_OUTPUT,      {SLEEP,    WAIT_S,   WAIT_S, WAIT_S, PAIRED_S, WAIT_S, WAIT_S}},
      /* 3 - PAIR_ACK */ {MILLISECONDS(300), PAIR_ACK_OUTPUT,  {PAIR_ACK_S,   SLEEP_S,  SLEEP_S, SLEEP_S, SLEEP_S, SLEEP_S, SLEEP_S}},
      /* 4 - PAIRED   */ {MILLISECONDS(20), PAIRED_OUTPUT,    {SLEEP_S, SLEEP_S, SLEEP_S, SLEEP_S, SLEEP_S, SLEEP_S, SLEEP_S}}
    };

    FSM_Pair();
    void executeFSM();
    bool pairCommandReceived = false;
    Packet dataPacket;
    bool BLEconnected = false;
    bool shouldResetFSM = false;
    bool p_radioActive = false;

  private:
    void handleOutputs(uint16_t output);
    uint16_t getInputs();

    void p(String value, bool doIt);
    void showOutputs(uint16_t output);
    void showInputs(uint16_t input);
    void showState(uint8_t state);
    uint16_t forceInputs();
    BLEWake wake;

    States _currentState = SLEEP_S;
    Flash _flash;
    int64_t _delayTimeOut;
    Button _theButton;
    uint16_t _outputs;
    uint16_t _inputs;
    LED _led;
};

#endif

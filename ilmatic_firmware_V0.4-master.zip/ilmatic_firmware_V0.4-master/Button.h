#ifndef Button_H
#define Button_H

#include "BLEWake.h"
#include "Arduino.h"
#include "Flash.h"

class Button
{
  public:
    int isPressed(int button);
    void delay_until_button(int state, BLEWake wake, int64_t delay);
    bool wokeFromButton();
    
  private:
    int debounce(int state);
    Flash _flash;
};

#endif


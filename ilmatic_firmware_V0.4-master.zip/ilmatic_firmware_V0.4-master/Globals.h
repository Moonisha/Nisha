#ifndef Globals_H
#define Globals_H

#include "Arduino.h"

#define BLINK_COUNT 5
#define BLINK_DELAY_TIME_MS MILLISECONDS(50)
#define MAIN_LOOP_DELAY MILLISECONDS(100)

#define ADVERTISING_TIME_OUT MILLISECONDS(10000)
#define CONNECTION_TIME_OUT MILLISECONDS(10000)

//#define LED_VID_DEMO
#define SERIAL 1
//#define TESTHARDWARE


#ifdef TESTHARDWARE

#define RED_LED 2 // Red
#define GREEN_LED 3 //Green
#define BLUE_LED 4 //Blue
#define BUTTON_1 5
#define BUTTON_PULLUP false
#define BUZZER_PIN 6

#define WIRING_ON HIGH  // To get LED to light

#else

#define RED_LED 29 // Red
#define GREEN_LED 21 //Green
#define BLUE_LED 4 //Blue
#define BUTTON_1 30
#define BUZZER_PIN 5
#define BUTTON_PULLUP true

#define WIRING_ON LOW  // To get LED to light

#endif
#define ACK_BYTE 0xAC

typedef enum {OFF, QUARTER, HALF_HOUR, NOT_USED,HOUR} ClockMode;

#endif

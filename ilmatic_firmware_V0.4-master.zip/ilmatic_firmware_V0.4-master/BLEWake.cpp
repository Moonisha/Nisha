#include "BLEWake.h"

BLEWake::BLEWake(){
  _ble = 25;

  pinMode(_ble, INPUT_PULLDOWN);
  NRF_GPIO->PIN_CNF[_ble] = (GPIO_PIN_CNF_PULL_Pulldown << GPIO_PIN_CNF_PULL_Pos); // use pulldown
  Simblee_pinWake(_ble,HIGH);
  //Simblee_resetPinWake(_ble); // +++ <-- timb103 added this line // crt 051516 took out timb103 addition, wrong use. Proper use after pinWoke* function
}//end BLEWake()

void BLEWake::wakeFromBLEEvent(){
  digitalWrite(_ble, HIGH);
  // need to bring internal pin high somehow.. so..
  NRF_GPIO->PIN_CNF[_ble] = (GPIO_PIN_CNF_PULL_Pullup<<GPIO_PIN_CNF_PULL_Pos);
  Simblee_pinWake(_ble,HIGH);
  // need to bring internal pin low again.. so..
  NRF_GPIO->PIN_CNF[_ble] = (GPIO_PIN_CNF_PULL_Pulldown<<GPIO_PIN_CNF_PULL_Pos);
}//end BLEWake::wakeFromBLEEvent()

bool BLEWake::didWakeFromBLE(){
  if(Simblee_pinWoke(_ble)){
    Simblee_resetPinWake(_ble);
    return true; // return true if woke
  }
  return false; // return false if not woke
}//end BLEWake::didWakeFromBLE()

//gi

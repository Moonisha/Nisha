#ifndef Packet_H
#define Packet_H

#include <stdio.h>
#include "stdint.h"

#define MAX_PACKET_LENGTH 255 //Words

class Packet{
  public:
    void addChar(char value);
    void clear();
    char checksum();
    char startWord();
    char getCharAtIndex(uint8_t index);
    uint8_t length();
    uint8_t dataLength();
    void read(char *payload, int len);
    void send();
  private:
    char _data[MAX_PACKET_LENGTH];
    uint8_t _index;
};

#endif



#ifndef BLEWake_h
#define BLEWake_h

#include "SimbleeBLE.h"
#include "Arduino.h"

class BLEWake
{
  public:
    BLEWake();
    void wakeFromBLEEvent();
    bool didWakeFromBLE();
  private:
    int _ble;
};

#endif

//gi

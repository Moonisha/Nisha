#ifndef FSM_HACK_H
#define FSM_HACK_H

#include <stdint.h>
#include <Arduino.h>
#include "Globals.h"
#include "Flash.h"
#include "BLEWake.h"
#include "Packet.h"
#include "Button.h"
#include "LED.h"

#define ENAB_BUZZER_T MILLISECONDS(300)
#define WAIT_BTN_REL_T SECONDS(1)

// Outputs
#define RED_LED_ON 0     // RED
#define GREEN_LED_ON 1   // GREEN
#define BLUE_LED_ON 2    // BLUE
#define MOTOR_ON 3       // MOTOR
#define RADIO_ON 4       // RADIO
#define SET_HACK_1 5     // HACK_1
#define SET_HACK_2 6     // HACK_2
#define SET_HACK_3 7     // HACK 3
#define PAIR_ACK 8       // ACK
#define FLASH_LEDS 9     // FLASH
#define SLEEP 10         // SLEEP
#define INC_COUNT 11     // INCREMENT COUNT AND SAVE
#define CLEAR_COUNT 12   // CLEAR COUNT AND SAVE
#define SYNC_CLOCK 13    // SYNC CLOCK AND SAVE
#define SYNC_SLEEP 14    // SLEEP WITH SHORTER TIMEOUT
#define RESET_TIME_OFFSET 15 // MOVE BACK TO 15 MINUTE INTERVALS

#define YELLOW_LED_ON (1 << GREEN_LED_ON) | (1 << RED_LED_ON)

#define SLEEP_OUTPUT        (1 << SLEEP)
#define BUZZ_1_OUTPUT       (1 << BLUE_LED_ON) | (1 << SLEEP) | (1 << MOTOR_ON)     // HOLD & PRESS 1 SECOND 
#define BUZZ_1_DONE_OUTPUT  (1 << SLEEP)
#define BUZZ_2_OUTPUT       (1 << BLUE_LED_ON) | (1 << SLEEP) | (1 << MOTOR_ON)     // HOLD & PRESS 2 SECONDS
#define BUZZ_2_DONE_OUTPUT  (1 << SLEEP)
#define BUZZ_3_OUTPUT       (1 << BLUE_LED_ON) | (1 << SLEEP) | (1 << MOTOR_ON)     // HOLD & PRESS 3 SECONDS
#define BUZZ_3_DONE_OUTPUT  (1 << SLEEP)
#define HACK_1_OUTPUT       (1 << SET_HACK_1) | (1 << RADIO_ON) | (1 << BLUE_LED_ON)     // SENDING DATA TO PHONE
#define HACK_2_OUTPUT       (1 << SET_HACK_2) | (1 << RADIO_ON) | (1 << BLUE_LED_ON)     // SENDING DATA TO PHONE
#define HACK_3_OUTPUT       (1 << SET_HACK_3) | (1 << RADIO_ON) | (1 << BLUE_LED_ON)     // SENDING DATA TO PHONE
#define WAIT_ACK_OUTPUT     (1 << RED_LED_ON) | (1 << RADIO_ON)
#define ACK_OUTPUT          (1 << FLASH_LEDS) | (1 << SLEEP)
#define INC_COUNT_OUTPUT    (1 << INC_COUNT) | (1 << RESET_TIME_OFFSET)
#define CLOCK_BUZZ_OUTPUT   (1 << GREEN_LED_ON) | (1 << SLEEP) | (1 << CLEAR_COUNT) | (1 << MOTOR_ON)
#define CLOCK_ADV_OUTPUT    (1 << BLUE_LED_ON) | (1 << RADIO_ON)
#define CLOCK_WAIT_OUTPUT   (1 << RED_LED_ON) | (1 << RADIO_ON)
#define CLOCK_SYNC_OUTPUT   (1 << SYNC_CLOCK) | (1 << FLASH_LEDS)
#define CLOCK_SLEEP_OUTPUT  (1 << SYNC_SLEEP)

class FSM_Hack
{
  public:
    typedef enum {SLEEP_S, BUZZ_1_S, BUZZ_1_DONE_S, BUZZ_2_S, BUZZ_2_DONE_S,BUZZ_3_S, BUZZ_3_DONE_S, HACK_1_S, HACK_2_S, HACK_3_S, WAIT_ACK_S, ACK_S, INC_COUNT_S, CLOCK_BUZZ_S, CLOCK_ADV_S, CLOCK_WAIT_S, CLOCK_SYNC_S, CLOCK_SLEEP_S, NumberOfStates} States;
    typedef enum {NONE_I, BTN_PRESSED_I, BTN_RELEASED_I, CONNECTED_I, ACK_RECEIVED_I, CLOCK_COUNT_EQUAL_MODE_I, SYNC_CLOCK_I, NumberOfInputs} Inputs;

    typedef struct fsm_item
    {
      int64_t timeOutTime;
      uint16_t output;
      uint16_t nextState[NumberOfInputs];
    } fsm_item_s;

    fsm_item_s fsm[NumberOfStates] = { //                           NONE_I,       BTN_PRESSED, BTN_RELEASED, CONNECTED,  ACK_RECEIVED, CLOCK_COUNT_EQUAL_MODE_I, SYNC_CLOCK_I
      /* 0 - SLEEP       */ {-1 /*grab from flash*/, SLEEP_OUTPUT,  {INC_COUNT_S, BUZZ_1_S,      INC_COUNT_S,   SLEEP_S,      SLEEP_S,    CLOCK_BUZZ_S,    SLEEP_S}},
      /* 1 - BUZZ_1      */ {ENAB_BUZZER_T,     BUZZ_1_OUTPUT,      {SLEEP_S,     BUZZ_1_DONE_S, SLEEP_S,      SLEEP_S,      SLEEP_S,    SLEEP_S,    SLEEP_S}},
      /* 2 - BUZZ_1_DONE */ {WAIT_BTN_REL_T,    BUZZ_1_DONE_OUTPUT, {SLEEP_S,     BUZZ_2_S,      HACK_1_S,     SLEEP_S,      SLEEP_S,    SLEEP_S,    SLEEP_S}},
      /* 3 - BUZZ_2      */ {ENAB_BUZZER_T,     BUZZ_2_OUTPUT,      {SLEEP_S,     BUZZ_2_DONE_S, SLEEP_S,      SLEEP_S,      SLEEP_S,    SLEEP_S,    SLEEP_S}},
      /* 4 - BUZZ_2_DONE */ {WAIT_BTN_REL_T,    BUZZ_2_DONE_OUTPUT, {SLEEP_S,     BUZZ_3_S,      HACK_2_S,     SLEEP_S,      SLEEP_S,    SLEEP_S,    SLEEP_S}},
      /* 3 - BUZZ_3      */ {ENAB_BUZZER_T,     BUZZ_3_OUTPUT,      {SLEEP_S,     BUZZ_3_DONE_S, SLEEP_S,      SLEEP_S,      SLEEP_S,    SLEEP_S,    SLEEP_S}},
      /* 4 - BUZZ_3_DONE */ {WAIT_BTN_REL_T,    BUZZ_3_DONE_OUTPUT, {SLEEP_S,     SLEEP_S,       HACK_3_S,     SLEEP_S,      SLEEP_S,    SLEEP_S,    SLEEP_S}},
      /* 5 - HACK_1      */ {SECONDS(10),       HACK_1_OUTPUT,      {SLEEP_S,     SLEEP_S,       SLEEP_S,      WAIT_ACK_S,   SLEEP_S,    SLEEP_S,    SLEEP_S}},
      /* 6 - HACK_2      */ {SECONDS(10),       HACK_2_OUTPUT,      {SLEEP_S,     SLEEP_S,       SLEEP_S,      WAIT_ACK_S,   SLEEP_S,    SLEEP_S,    SLEEP_S}},
      /* 6 - HACK_3      */ {SECONDS(10),       HACK_3_OUTPUT,      {SLEEP_S,     SLEEP_S,       SLEEP_S,      WAIT_ACK_S,   SLEEP_S,    SLEEP_S,    SLEEP_S}},
      /* 7 - WAIT_ACK    */ {SECONDS(10),       WAIT_ACK_OUTPUT,    {SLEEP_S,     BUZZ_1_S,      SLEEP_S,      SLEEP_S,      ACK_S,      SLEEP_S,    SLEEP_S}},
      /* 8 - ACK         */ {MILLISECONDS(20),  ACK_OUTPUT,         {SLEEP_S,     SLEEP_S,       SLEEP_S,      SLEEP_S,      SLEEP_S,    SLEEP_S,    SLEEP_S}},
     // -----------------------------------------------------------------------------------------------------------------------------------------------------------//
      /* 9 - INC_COUNT   */ {MILLISECONDS(20),  INC_COUNT_OUTPUT,   {CLOCK_ADV_S, CLOCK_ADV_S,   CLOCK_ADV_S,  CLOCK_ADV_S,  CLOCK_ADV_S, CLOCK_BUZZ_S, SLEEP_S}},
      /* 10 - CLOCK_BUZZ */ {SECONDS(2),        CLOCK_BUZZ_OUTPUT,  {CLOCK_ADV_S, CLOCK_ADV_S,   CLOCK_ADV_S,  CLOCK_ADV_S,  CLOCK_ADV_S, CLOCK_ADV_S, SLEEP_S}},
      /* 11 - CLOCK_ADV  */ {SECONDS(10),       CLOCK_ADV_OUTPUT,   {SLEEP_S,     SLEEP_S,       SLEEP_S,      CLOCK_WAIT_S, SLEEP_S,     SLEEP_S,    SLEEP_S}},
      /* 12 - CLOCK_WAIT */ {SECONDS(10),       CLOCK_WAIT_OUTPUT,  {SLEEP_S,     SLEEP_S,       SLEEP_S,      SLEEP_S,      SLEEP_S,     SLEEP_S,    CLOCK_SYNC_S}},
      /* 13 - CLOCK_SYNC */ {MILLISECONDS(20),  CLOCK_SYNC_OUTPUT,  {CLOCK_SLEEP_S,CLOCK_SLEEP_S,CLOCK_SLEEP_S,CLOCK_SLEEP_S,CLOCK_SLEEP_S,CLOCK_SLEEP_S,CLOCK_SLEEP_S}},  
      /* 14 - CLOCK_SLEEP */{MINUTES(15),       CLOCK_SLEEP_OUTPUT, {INC_COUNT_S, BUZZ_1_S,      SLEEP_S,      SLEEP_S,      SLEEP_S,     SLEEP_S,    SLEEP_S}}
    };

    FSM_Hack();
    void executeFSM();
    bool ackReceived = false;
    Packet dataPacket;
    bool BLEconnected = false;
    void resetStateMachine();
    bool h_radioActive = false;

  private:
    bool _stateMachineJustReset = false;
    void handleOutputs(uint16_t output);
    uint16_t getInputs();

    void p(String value, bool doIt);
    void showOutputs(uint16_t output);
    void showInputs(uint16_t input);
    void showState(uint8_t state);
    uint16_t forceInputs();
    BLEWake wake;
    States _currentState = SLEEP_S;
    Flash _flash;
    int64_t _delayTimeOut;
    Button _theButton;
    uint16_t _outputs;
    uint16_t _inputs;
    LED _led;

};

#endif

#ifndef Flash_H
#define Flash_H

#include <stdint.h>
#include <Arduino.h>
#include "Globals.h"

#define MY_FLASH_PAGE  251 // See Memory.h for more info
#define MAGIC_NUMBER 0xCAFEBABE

class Flash
{
    struct data_t
    {
      int magicNumber;
      int paired;
      int clockMode; // 0 - off, 1 - quarter, 2 - half, 4 - hour
      int64_t clockOffset; // time to next wake-up.  if 
      int64_t sleepTime; // Time going to sleep in micros
      int clockWakeCount;
    };

  public:
    Flash();
    void printContentsOfFlash();
    void printContentsOfRAM();
    
    void flashUpdate(int pair);
    void manageFlash();
    bool paired();
    ClockMode clockMode();
    float clockOffset();
    int clockWakeCount();
    int64_t sleepTime();

    void recordCurrentTime();
    void incrementClockWakeCount();
    void setClockMode(ClockMode value);
    void setClockOffset(int64_t value);
    void setPaired(bool value);
    void clearWakeCount();
    
    void writeFlash();
    void readFlashIntoRAM();

  private:
    struct data_t *_flash = (data_t*)ADDRESS_OF_PAGE(MY_FLASH_PAGE);
    struct data_t _ram;

};

#endif


#include "Flash.h"
#include "Arduino.h"
Flash::Flash(){

}//Constructor

bool Flash::paired(){
  //return (_flash->paired == 1);//crt 051516
  return _flash->paired;
}//END paired()

void Flash::flashUpdate(int pair){
  flashPageErase(MY_FLASH_PAGE);

  struct data_t value;
  value.magicNumber = 0xCAFEBABE;
  value.paired = pair;
  value.clockMode = OFF;
  value.clockOffset = 15;
  value.clockWakeCount = 0;
  flashWriteBlock(_flash, &value, sizeof(value));
  readFlashIntoRAM();
}//END flashUpdate

void Flash::printContentsOfFlash(){
  #ifdef SERIAL
  Serial.print("Flash Magic Number: "); Serial.println(_flash->magicNumber, HEX);
  Serial.print("Flash Pair: "); Serial.println(_flash->paired, HEX);
  Serial.print("Flash Clock Mode: "); Serial.println(_flash->clockMode, HEX);
  Serial.print("Flash Clock Offset: "); Serial.println((int)_flash->clockOffset);
  Serial.print("Flash Clock Wake Count: "); Serial.println(_flash->clockWakeCount);
  #endif
}//END printContentsOfFlash()

void Flash::printContentsOfRAM(){
  #ifdef SERIAL
  Serial.print("RAM Magic Number: "); Serial.println(_ram.magicNumber, HEX);
  Serial.print("RAM Pair: "); Serial.println(_ram.paired, HEX);
  Serial.print("RAM Clock Mode: "); Serial.println(_ram.clockMode, HEX);
  Serial.print("RAM Clock Offset: "); Serial.println((int)_ram.clockOffset);
  Serial.print("RAM Clock Wake Count: "); Serial.println(_ram.clockWakeCount);
  #endif
}//End printContentsOfRAM

int64_t Flash::sleepTime(){
  return _flash->sleepTime;
}//End sleepTime

void Flash::recordCurrentTime(){
  _flash->sleepTime = micros();
  _ram.sleepTime = _flash->sleepTime;
}//END recordCurrentTime

ClockMode Flash::clockMode(){
  return (ClockMode)_flash->clockMode;
}//End clockMode

void Flash::setClockOffset(int64_t value){
  _flash->clockOffset = value;
  _ram.clockOffset = value;
}//Eend SetClockOffset

float Flash::clockOffset(){
  return _flash->clockOffset;
}//End clockOffSet

void Flash::manageFlash(){
  if (_flash->magicNumber != MAGIC_NUMBER){
    #ifdef SERIAL
    Serial.println("Initializing Flash for the first time");
    #endif
    flashUpdate(0);
  }else{
    #ifdef SERIAL
    Serial.print("Flash says pair = "); Serial.println(_flash->paired);
    #endif
  }
}//End ManageFlash

void Flash::setPaired(bool value){
  _flash->paired = value;
  _ram.paired = value;
}//End setPair

void Flash::setClockMode(ClockMode value){
  _flash->clockMode = value;
  _ram.clockMode = value;
}//End setClockMode()

int Flash::clockWakeCount(){
  return _ram.clockWakeCount;
}//End clockWakeCount

void Flash::incrementClockWakeCount(){
  _ram.clockWakeCount++;
}//End incrementClockWakeCount

void Flash::clearWakeCount(){
  _ram.clockWakeCount = 0;
}//End clearWakeCount

void Flash::readFlashIntoRAM(){
//  Serial.println("reading flash into ram");
  _ram.magicNumber = _flash->magicNumber;
  _ram.paired = _flash->paired;
  _ram.clockMode = _flash->clockMode;
  _ram.clockOffset = _flash->clockOffset;
  _ram.clockWakeCount = _flash->clockWakeCount;
}//End readFlashIntoRAM

void Flash::writeFlash(){// radioActive? crt51816
 // Serial.println("Writing to Flash...");
  _flash->magicNumber = _ram.magicNumber ;
  _flash->paired = _ram.paired ;
  _flash->clockMode = _ram.clockMode;
  _flash->clockOffset = _ram.clockOffset;
  _flash->clockWakeCount = _ram.clockWakeCount;

//  Serial.println("BEFORE------------------");
//  printContentsOfRAM();
//  printContentsOfFlash();
//  Serial.println("------------------");

  flashPageErase(MY_FLASH_PAGE);
  flashWriteBlock(_flash, &_ram, sizeof(_ram));
  
//  Serial.println("AFTER------------------");
//  printContentsOfRAM();
//  printContentsOfFlash();
//  Serial.println("------------------");
}//END writeFlash


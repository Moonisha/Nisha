#include "Packet.h"
#include "SimbleeBLE.h"

#define START_WORD_INDEX 0
#define WORD_COUNT_INDEX 1
#define CHECKSUM_OFFSET 2
#define START_WORD 0x7F


void Packet::read(char *payload, int len){
  clear();
  for (int i = 2; i < len - 1; i++){
    addChar(payload[i]);
  }
}//End read

void Packet::send(){
  #ifdef SERIAL
  Serial.println("sending data");
  for (int i=0; i<_index+CHECKSUM_OFFSET+1; i++)
  {
    Serial.print((uint8_t)_data[i],HEX);
  }
  Serial.println();
  #endif
  SimbleeBLE.send(_data, _index + CHECKSUM_OFFSET + 1);
}//End send

void Packet::addChar(char value){
    // Make sure we haven't exceeded the maximum size of the data array
    if (_index + CHECKSUM_OFFSET < MAX_PACKET_LENGTH)
    {
        _data[_index + CHECKSUM_OFFSET] = value;
        _index++;
    }
    _data[WORD_COUNT_INDEX] = _index; //Set the word count
    _data[_index + CHECKSUM_OFFSET] = checksum();
}//End addChar

char Packet::getCharAtIndex(uint8_t index){
    return _data[index + CHECKSUM_OFFSET];
}//End getCharAtIndex

char Packet::startWord(){
    return _data[START_WORD_INDEX];
}//End startWord

uint8_t Packet::length(){
    return _index;
}//End length

uint8_t Packet::dataLength(){
  return _index-3;
}//end dataLength

char Packet::checksum(){
    int result = 0;
    for (int i=0; i < _index; i++){
        result += _data[i + CHECKSUM_OFFSET];
    }
    return result;
}//end checksum

void Packet::clear(){
    _index = 0;
    _data[START_WORD_INDEX] = START_WORD;
    _data[WORD_COUNT_INDEX] = _index;
    _data[_index + CHECKSUM_OFFSET] = checksum();
}//end clear


//End Packet.cpp

#include "FSM_HACK.h"
#include <stdint.h>
#include "SimbleeBLE.h"

FSM_Hack::FSM_Hack(){
  _currentState = SLEEP_S;
  h_radioActive = false;
}//Constructor

void FSM_Hack::handleOutputs(uint16_t output){
  _led.setColor(output & (1 << RED_LED_ON), output & (1 << GREEN_LED_ON), output & (1 << BLUE_LED_ON));
//MOTOR ON  
  if (output & (1 << MOTOR_ON)){
    digitalWrite(BUZZER_PIN, HIGH);
  }else{
    digitalWrite(BUZZER_PIN, LOW);
  }
  
  char advData[8] = "!______";
//SET HACK 1  
  if (output & (1 << SET_HACK_1)) {
    advData[1] = 'H'; advData[2] = '1';
  }
//SET HACK 2  
  if (output & (1 << SET_HACK_2)) {
    advData[1] = 'H'; advData[2] = '2';
  }
//SET HACK 3  
  if (output & (1 << SET_HACK_3)) {
    advData[1] = 'H'; advData[2] = '3';
  }
// INC COUNT  /// why not have radioActive while loop here? crt51816
  if (_flash.clockMode() > 0){
    if (output & (1 << INC_COUNT)) {
      _flash.readFlashIntoRAM();
      _flash.incrementClockWakeCount();
      _flash.writeFlash();
    }
  }
// CLEAR COUNT  // why not have radioActive while loop here? crt51816 
  if (output & (1 << CLEAR_COUNT)) {
    _flash.readFlashIntoRAM();
    _flash.clearWakeCount();
    _flash.writeFlash();
  }
//RESET TIME OFFSET  // why not have radioActive in loop here? crt51816
  if (output & (1 << RESET_TIME_OFFSET)) {
    _flash.readFlashIntoRAM();
    int64_t nextWake = 15 * 60 * 1000 + millis();
    _flash.setClockOffset(nextWake);
    _flash.writeFlash();
    #ifdef SERIAL
      Serial.println("Set new wake time");
    #endif
  }

  advData[3] = _flash.clockMode() + 0x30;
  SimbleeBLE.advertisementData = advData;
  
//RADIO ACTIVE  
  if (output & (1 << RADIO_ON)){
    if (!h_radioActive) {
      SimbleeBLE.begin();
      h_radioActive = true;
    }
  }else{
    SimbleeBLE.end();
    h_radioActive = false;
  }

//FLASH_LEDS 
  if (output & (1 << FLASH_LEDS)){
    _led.flash(0, 255, 0);//GREEN
  }
  //_flash.printContentsOfFlash();
//DELAY TIME OUT // radioactive? crt51816
  if (_delayTimeOut < 0){
    _delayTimeOut = _flash.clockOffset() - millis(); 
    if (_delayTimeOut < 0) 
    {
      _delayTimeOut = 0;
    }
  }

  #ifdef SERIAL
  Serial.print("Hack ZZZ Delay: "); Serial.println((int)_delayTimeOut);
  Serial.print((int)_delayTimeOut); Serial.println(" ...");
  #endif
  
//BUTTON_1 IS PRESSED  
  if (_theButton.isPressed(BUTTON_1)){
    _theButton.delay_until_button(LOW, wake, _delayTimeOut);
  }else{
    _theButton.delay_until_button(HIGH, wake, _delayTimeOut);
  }
  
  wake.didWakeFromBLE();
  
}//END FSM_HACK :: Handle Outputs

void FSM_Hack::resetStateMachine(){
  _stateMachineJustReset = true;
}//END FSM_HACK :: resetStateMachine()

uint16_t FSM_Hack::getInputs(){
  // Debug State machine by forcing inputs and watching it run correctly through all the states
  //   return forceInputs();
  // End of debug

  uint16_t result = NONE_I;
  
  if (Simblee_pinWoke(BUTTON_1)){
    Simblee_resetPinWake(BUTTON_1);
  }
  
  if (_theButton.isPressed(BUTTON_1)){
    result = BTN_PRESSED_I;
  }else{
    result = BTN_RELEASED_I;
  }
  if (BLEconnected) result = CONNECTED_I;
  if (ackReceived)  result = ACK_RECEIVED_I;
  
  ackReceived = false;
  BLEconnected = false;

  if ((_flash.clockWakeCount() >= _flash.clockMode()) && (_flash.clockMode() > 0)){
    result = CLOCK_COUNT_EQUAL_MODE_I;
  }

  return result;
}//END FSM_HACK :: getInputs()

void FSM_Hack::executeFSM(){
  showState(_currentState);
  showInputs(_inputs);
  
  if (!_stateMachineJustReset){
    _inputs = getInputs();
    _currentState = (States)fsm[_currentState].nextState[_inputs];
  }
  
  _outputs = fsm[_currentState].output;
  _delayTimeOut = fsm[_currentState].timeOutTime;
  
  showState(_currentState);
  _stateMachineJustReset = false;
  
  showOutputs(_outputs); 
  
  #ifdef SERIAL  
    Serial.println();
  #endif
  
  handleOutputs(_outputs);
}// End FSM_Hack executeFSM()



//---------------------------
// Debug functions
//---------------------------
void FSM_Hack::p(String value, bool doIt){
  #ifdef SERIAL
  if (doIt){
    Serial.print("|");
    Serial.print(value);
  }
  else Serial.print("|_____");
  #endif
}//end FSM_HACK :: p

void FSM_Hack::showOutputs(uint16_t output){
  #ifdef SERIAL
  Serial.print(" : ");
  Serial.print(_flash.clockWakeCount());
  Serial.print(" : ");
  Serial.print(_flash.clockMode());
  Serial.print(" : ");
  #endif
  p("SLEEP", (output & (1 << SLEEP)));
  p("FLASH", (output & (1 << FLASH_LEDS)));
  p("ACK  ", (output & (1 << PAIR_ACK)));
  p("HACK1", (output & (1 << SET_HACK_1)));
  p("HACK2", (output & (1 << SET_HACK_2)));
  p("HACK3", (output & (1 << SET_HACK_3)));
  p("RADIO", (output & (1 << RADIO_ON)));
  p("MOTOR", (output & (1 << MOTOR_ON)));
  p("BLUE", (output & (1 << BLUE_LED_ON)));
  p("GREEN", (output & (1 << GREEN_LED_ON)));
  p("RED", (output & (1 << RED_LED_ON)));
  p("SYNC_CLOCK", (output & (1 << SYNC_CLOCK)));
  p("SYNC_SLEEP", (output & (1 << SYNC_SLEEP)));
}// End FSM_HACK:: showOutputs()

void FSM_Hack::showInputs(uint16_t input){
  #ifdef SERIAL
  Serial.print(" >> ");
  switch (input){
    case NONE_I :         Serial.print("NONE        "); break;
    case BTN_PRESSED_I :  Serial.print("BTN_PRESSED"); break;
    case BTN_RELEASED_I : Serial.print("BTN_RELEASED  "); break;
    case CONNECTED_I :    Serial.print("CONNECTED   "); break;
    case ACK_RECEIVED_I : Serial.print("ACK_RECEIVED"); break;
    case CLOCK_COUNT_EQUAL_MODE_I : Serial.print("CLOCK_MODE_EQUAL"); break;
    case SYNC_CLOCK_I : Serial.print("SYNC_CLOCK"); break;
    default: Serial.print("NONE        ");
  }

  Serial.print(" << ");
  #endif
}// end FSM_HACK Show Inputs

void FSM_Hack::showState(uint8_t state){
  #ifdef SERIAL
  if (_stateMachineJustReset){
    Serial.print("***");
  }
  switch (state){
    case SLEEP_S :        Serial.print("(H_FSM)[SLEEP   ]"); break;
    case BUZZ_1_S :       Serial.print("(H_FSM)[BUZZ_1  ]"); break;
    case BUZZ_1_DONE_S :  Serial.print("(H_FSM)[BUZZ_1_D]"); break;
    case BUZZ_2_S :       Serial.print("(H_FSM)[BUZZ_2  ]"); break;
    case BUZZ_2_DONE_S :  Serial.print("(H_FSM)[BUZZ_2_D]"); break;
    case BUZZ_3_S :       Serial.print("(H_FSM)[BUZZ_3  ]"); break;
    case BUZZ_3_DONE_S :  Serial.print("(H_FSM)[BUZZ_3_D]"); break;
    case HACK_1_S :       Serial.print("(H_FSM)[HACK_1  ]"); break;
    case HACK_2_S :       Serial.print("(H_FSM)[HACK_2  ]"); break;
    case HACK_3_S :       Serial.print("(H_FSM)[HACK_3  ]"); break;
    case WAIT_ACK_S :     Serial.print("(H_FSM)[WAIT_ACK]"); break;
    case INC_COUNT_S :    Serial.print("(H_FSM)[INC_COUNT_S]"); break;
    case CLOCK_BUZZ_S :   Serial.print("(H_FSM)[CLOCK_BUZZ_S]"); break;
    case CLOCK_ADV_S :    Serial.print("(H_FSM)[CLOCK_ADV_S]"); break;
    case CLOCK_WAIT_S :   Serial.print("(H_FSM)[CLOCK_WAIT_S]"); break;
    case CLOCK_SYNC_S :   Serial.print("(H_FSM)[CLOCK_SYNC_S]"); break;
    case CLOCK_SLEEP_S :  Serial.print("(H_FSM)[CLOCK_SLEEP_S]"); break;
    default: break;
  }
  #endif
}//END FSM_HACK showState()

uint16_t FSM_Hack::forceInputs(){
  uint16_t result = 0;
  switch (_currentState){
    case SLEEP_S :  result = BTN_PRESSED_I;  break;
    case BUZZ_1_S : result = BTN_PRESSED_I;   break;
    case BUZZ_1_DONE_S : result = BTN_RELEASED_I;  break;
    case HACK_1_S : result = CONNECTED_I; break;
    case HACK_2_S : result = CONNECTED_I; break;
    case HACK_3_S : result = CONNECTED_I; break;
    case WAIT_ACK_S : result = ACK_RECEIVED_I; break;
    case ACK_S : result = NONE_I; break;
    default:
      break;
  }
  return result;
}//End FSM_Hack forceInputs



#include "FSM_Pair.h"
#include <stdint.h>
#include "SimbleeBLE.h"

FSM_Pair::FSM_Pair(){
  _currentState = SLEEP_S;
  p_radioActive = false;
}//Constructor

void FSM_Pair::handleOutputs(uint16_t output){
  _led.setColor(output & (1 << RED_LED_ON), output & (1 << GREEN_LED_ON), output & (1 << BLUE_LED_ON));
//RESET HACK FSM
  if (output & (1 << RESET_H_FSM)){
     #ifdef SERIAL
      Serial.print("Reset Hack FSM"); Serial.println(" ...");
     #endif
    shouldResetFSM = true;
  }
  //  digitalWrite(RED_LED, (output & (1 << RED_LED_ON)));
  //  digitalWrite(GREEN_LED, (output & (1 << GREEN_LED_ON)));
  //  digitalWrite(BLUE_LED, (output & (1 << BLUE_LED_ON)));
//RADIO ON  
  if (output & (1 << RADIO_ON)){
    if (_flash.paired()){
      SimbleeBLE.advertisementData = "!";
      #ifdef SERIAL
      Serial.print("advertisement !"); Serial.println(" ...");
     #endif
    }else{
      SimbleeBLE.advertisementData = "?";
      #ifdef SERIAL
      Serial.print("advertisement ?"); Serial.println(" ...");
     #endif
    }

    if (!p_radioActive) {
      SimbleeBLE.begin();
      p_radioActive = true;
    }
  }else{
    while (SimbleeBLE.radioActive) {
      ;;
    }
    #ifdef SERIAL
      Serial.print("Radio wait"); Serial.println(" ...");
     #endif
    //Simblee_ULPDelay(30); //ULP Delay causing issues here crt51916
    //    Serial.println("Shutting Down Radio");
    SimbleeBLE.end();
    p_radioActive = false;
  }
//SET PAIR  
  if (output & (1 << SET_PAIR))
  {
    _flash.readFlashIntoRAM();
    _flash.setPaired(true);
    _flash.writeFlash();
    #ifdef SERIAL
      Serial.print("Set Pair"); Serial.println(" ...");
     #endif
  }
//PAIR ACK  
  if (output & (1 << PAIR_ACK)) {
    dataPacket.clear();
    dataPacket.addChar(ACK_BYTE); // acknowledge byte
    dataPacket.send();
    #ifdef SERIAL
      Serial.print("Pair ack"); Serial.println(" ...");
     #endif
  }
//FLASH LEDS  
  if (output & (1 << FLASH_LEDS)){
    _led.flash(0, 255, 0);//GREEN
    #ifdef SERIAL
      Serial.print("Flash leds"); Serial.println(" ...");
     #endif
  }

//  if (_delayTimeOut < 0)
//  {
//    _delayTimeOut = _flash.clockOffset() * 60000;  // Minutes to milliseconds;
//  }
  #ifdef SERIAL
  Serial.print("Pair ZZZ Delay: ");
  Serial.print((int)_delayTimeOut); Serial.println(" ...");
  #endif
  
  _theButton.delay_until_button(HIGH, wake, _delayTimeOut);
 
  #ifdef SERIAL
  Serial.print("Got passed button click"); Serial.println(" ...");
  #endif
  
  wake.didWakeFromBLE();

  #ifdef SERIAL
  Serial.print("Got passed did wake"); Serial.println(" ...");
  #endif
}//end handleOutputs

uint16_t FSM_Pair::getInputs(){
  // Debug State machine by forcing inputs and watching it run correctly through all the states
  //return forceInputs();
  // End of debug

  uint16_t result = NONE_I;
  
  if (Simblee_pinWoke(BUTTON_1)){
    //Simblee_resetPinWake(BUTTON_1);
    if (!BLEconnected){
      result = BTN_UNPAIRED_I;
        #ifdef SERIAL
      Serial.println("BTN_UNPAIRED ");
      #endif
      if (_flash.paired()){
        result = BTN_PAIRED_I;
                #ifdef SERIAL
      Serial.println("BTN_PAIRED ");
      #endif
      }
    }
  }
  if (BLEconnected){  
    result = CONNECTED_I;
          #ifdef SERIAL
      Serial.println("BLE CONNECTED ");
      #endif
  }else{
                #ifdef SERIAL
      Serial.println("BLE not connected ");
      #endif
    }
  
  if (pairCommandReceived){  
    result = PAIR_COMMAND_I;
            #ifdef SERIAL
      Serial.println("PAIR CMD RECIEVE ");
      #endif
  }else{
      #ifdef SERIAL
      Serial.println("PAIR CMD NOT RECIEVE ");
      #endif
    }

  BLEconnected = false;
  pairCommandReceived = false;
  return result;
}//End getInputs


void FSM_Pair::executeFSM(){
  _inputs = getInputs();//1. 
  showState(_currentState);//2. 
  showInputs(_inputs);//3. 
  _currentState = (States)fsm[_currentState].nextState[_inputs];//4. 
  showState(_currentState);//5. 
  _outputs = fsm[_currentState].output;//6. 
  _delayTimeOut = fsm[_currentState].timeOutTime;//7.
  showOutputs(_outputs);//8.
  #ifdef SERIAL
  Serial.println();
  #endif
  handleOutputs(_outputs);//9. // last thing this does is sleep if sleep is turned on
}//End executeFSM


//---------------------------
// Debug functions
//---------------------------
void FSM_Pair::p(String value, bool doIt){
  #ifdef SERIAL
  if (doIt)
  {
    Serial.print("|");
    Serial.print(value);
  }
  else Serial.print("|_____");
  #endif
}//End p

void FSM_Pair::showOutputs(uint16_t output){
  #ifdef SERIAL
  Serial.print(" :: ");
  #endif
  p("SLEEP", (output & (1 << SLEEP)));
  p("FLASH", (output & (1 << FLASH_LEDS)));
  p("ACK  ", (output & (1 << PAIR_ACK)));
  p("PAIR", (output & (1 << SET_PAIR)));
  p("RADIO", (output & (1 << RADIO_ON)));
  p("MOTOR", (output & (1 << MOTOR_ON)));
  p("_BLUE", (output & (1 << BLUE_LED_ON)));
  p("GREEN", (output & (1 << GREEN_LED_ON)));
  p("_RED_", (output & (1 << RED_LED_ON)));
  p("RESET_H_FSM", (output & (1 << RESET_H_FSM)));
}//End ShowOutputs

void FSM_Pair::showInputs(uint16_t input){
  #ifdef SERIAL
  Serial.print(" >>> ");
  switch (input)
  {
    case NONE_I :         Serial.print("NONE        "); break;
    case BTN_UNPAIRED_I : Serial.print("BTN_UNPAIRED"); break;
    case BTN_PAIRED_I :   Serial.print("BTN_PAIRED  "); break;
    case CONNECTED_I :    Serial.print("CONNECTED   "); break;
    case PAIR_COMMAND_I : Serial.print("PAIR_COMMAND"); break;
    case ADV_TO_I :       Serial.print("ADV_TO      "); break;
    case CONN_TO_I :      Serial.print("CONN_TO     "); break;
    default:
      break;
  }
  Serial.print(" << ");
  #endif
}//End showInputs

void FSM_Pair::showState(uint8_t state){
  #ifdef SERIAL
  switch (state){
    case SLEEP_S :    Serial.print("(P_FSM)[SLEEP   ]"); break;
    case ADV_S :      Serial.print("(P_FSM)[ADV     ]"); break;
    case WAIT_S :     Serial.print("(P_FSM)[WAIT    ]"); break;
    case PAIRED_S :   Serial.print("(P_FSM)[PAIRED  ]"); break;
    case PAIR_ACK_S : Serial.print("(P_FSM)[PAIR_ACK]"); break;
    default:
      break;
  }
  #endif
}//End showState

uint16_t FSM_Pair::forceInputs(){
  uint16_t result = 0;
  switch (_currentState){
    case SLEEP_S :  result = BTN_UNPAIRED_I;  break;
    case ADV_S :    result = CONNECTED_I;     break;
    case WAIT_S :   result = PAIR_COMMAND_I;  break;
    case PAIRED_S : result = 0;               break;
    default:
      break;
  }
  return result;
}//End forceInputs



#include "Button.h"
#include <stdint.h>
#include "Globals.h"

#define DEBOUNCE_TIMEOUT 100 // ms
#define DEBOUNCE_TIME 10

int Button::isPressed(int button){
  if (BUTTON_PULLUP){
    return !digitalRead(button);
  }else{
    return digitalRead(button);
  }
}//end Button::isPressed(int)

int Button::debounce(int state){
  int start = millis();
  int debounce_start = start;

  while (millis() - start < DEBOUNCE_TIMEOUT){
    //int value = digitalRead(BUTTON_1); // crt 12:12 05 06 16 Could get rid of value and put digitalRead into if statement
    if (digitalRead(BUTTON_1) == state){
      if (millis() - debounce_start >= DEBOUNCE_TIME) return 1;
    }else{
      debounce_start = millis();
    }
  }//end while
  
  return 0;
}//end Button:: debounce(int)

bool Button::wokeFromButton(){ // crt 12:22 05 06 16 changing contents of function based off of BLEWake::didWakeFromBLE()
                               // Necessary to add Simblee_resetPinWake, could be causing connectivity issues on wake up
    if(Simblee_pinWoke(BUTTON_1)){
     // Simblee_resetPinWake(BUTTON_1); crt51916 
      return true; // return true if woke
    }
      
    return false; // return false if not woke

}//end Button:: wokeFromButton()
 
void Button::delay_until_button(int state, BLEWake wake, int64_t b_delay){  
  if (BUTTON_PULLUP){
    state = !state;
  }
    //  Serial.print("Waiting for button to go to state: "); Serial.println(state);
  Simblee_pinWake(BUTTON_1, state);
  do{
    Simblee_ULPDelay(b_delay);
    if (wake.didWakeFromBLE()){
      #ifdef SERIAL
        Serial.print("BLE Wake...");
      #endif
      return;
    }
    
    if (!wokeFromButton()){
      #ifdef SERIAL
        Serial.print("Timeout Wake...");
      #endif
      return;
    }
  }while (! debounce(state));
  
  #ifdef SERIAL
    Serial.print("Button Wake...");
  #endif
  return;
}//end Button:: delay_until_button(int,BLEWake,int64_t)


//gi


